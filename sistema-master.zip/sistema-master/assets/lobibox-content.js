var IMG_PREFIX = 'assets/';
//LobiBox default options
Lobibox.notify.DEFAULTS = $.extend({}, Lobibox.notify.DEFAULTS, {
    sound: false,
    position: 'bottom left',
    title: false,
    delay: 5000,
    messageHeight: 90,
});
(function() {
    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>Gabriela Lima</b> acabou de comprar uma licença'
        });
    }, 7000);

    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>6 pessoas compraram nos últimos 15 minutos.</b>  <br><br><b>Clique</b> e garanta também o seu...'
        });
    }, 15000);

    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>Luan Souza</b> acabou de comprar uma licença!'
        });
    }, 23000);

    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>4 pessoas acabaram comprar</b>.<br><br><b>Clique</b> e garanta o também o seu...'
        });
    }, 31000);

    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>Julia Souza</b> acabou de comprar uma licença'
        });
    }, 39000);

    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>Sergio Abrãao</b> acabou de comprar comprar uma licença'
        });
    }, 47000);

    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>Gabriel Monteiro</b> acabou de comprar uma licença'
        });
    }, 55000);

    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>2 pessoas acabaram de comprar </b>.<br><br><b>Clique</b> e garanta o seu...'
        });
    }, 62000);

    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>Camila Santos</b> acabou de comprar uma licença'
        });
    }, 70000);
    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>Paulo Souza</b> acabou de comprar comprar uma licença'
        });
    }, 78000);
    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>Novas 5 pessoas compraram licença nos últimos 10 minutos</b>.<br><br><b>Clique</b> e garanta também o seu...'
        });
    }, 86000);
    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>Geissa Silva</b> acabou de comprar comprar uma licença'
        });
    }, 94000);
    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>Novas 6 pessoas compraram nos últimos 15 minutos.'
        });
    }, 102000);
    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>Breno Duarte</b> acabou de comprar uma licença'
        });
    }, 110000);
    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>4 pessoas acabaram comprar '
        });
    }, 118000);
    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>Rafael Souza</b> acabou de comprar uma licença'
        });
    }, 126000);
    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>Liomar Abrãao</b> acabou de comprar comprar uma licença'
        });
    }, 134000);
    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>Marcelo Victor</b> acabou de comprar comprar uma licença'
        });
    }, 142000);
    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>2 pessoas acabaram de comprar </b>.<br><br><b>Clique</b> e garanta o seu...'
        });
    }, 150000);
    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>Paula Roberto</b> acabou de comprar uma licença'
        });
    }, 158000);
    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>Geovane Nunes</b> acabou de comprar uma licença'
        });
    }, 166000);
    setTimeout(function() {
        Lobibox.notify('info', {
            img: IMG_PREFIX + '3-potes.png',
            msg: '<b>Novas 5 pessoas compraram  nos últimos 10 minutos</b>.<br><br><b>Clique</b> e garanta também o seu...'
        });
    }, 174000);
})();