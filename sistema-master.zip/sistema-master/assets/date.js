if (window.location.protocol !== 'https:') {
    //window.location = 'https://' + window.location.hostname + window.location.pathname + window.location.hash;
}
var dayNames = new Array("Domingo", "Segunda Feira", "Terça Feira", "Quarta Feira", "Quinta Feira", "Sexta Feira", "Sabado"),
    monthNames = new Array("Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"),
    now = new Date;
document.getElementById('data').innerHTML = (dayNames[now.getDay()] + ", " + now.getDate() + " De " + monthNames[now.getMonth()] + "  De " + now.getFullYear());